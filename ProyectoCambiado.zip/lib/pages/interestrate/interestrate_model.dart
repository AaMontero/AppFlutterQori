import '../../theme/aza_bank_util.dart';
import 'package:flutter/material.dart';

class InterestrateModel extends AzaBankModel {
  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {}

  /// Additional helper methods are added here.
}
