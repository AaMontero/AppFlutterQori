import '../../theme/aza_bank_util.dart';
import 'package:flutter/material.dart';

class AccountandcardModel extends AzaBankModel {
  ///  State fields for stateful widgets in this page.

  // State field(s) for PageView widget.
  PageController? pageViewController;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {}

  /// Additional helper methods are added here.
}
