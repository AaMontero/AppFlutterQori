// Export pages
export '/pages/welcome_page/welcome_page_widget.dart' show WelcomePageWidget;
export '/pages/login_page/login_page_widget.dart' show LoginPageWidget;
export '/pages/register_page/register_page_widget.dart' show RegisterPageWidget;
export '/pages/forgot_password/forgot_password_widget.dart'
    show ForgotPasswordWidget;
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/pages/search_page/search_page_widget.dart' show SearchPageWidget;
export '/pages/interestrate/interestrate_widget.dart' show InterestrateWidget;
export '/pages/searchfor_branch/searchfor_branch_widget.dart'
    show SearchforBranchWidget;
export '/pages/exchangerate/exchangerate_widget.dart' show ExchangerateWidget;
export '/pages/transfer_funds/transfer_funds_widget.dart'
    show TransferFundsWidget;
export '/pages/comfirm_tranfer/comfirm_tranfer_widget.dart'
    show ComfirmTranferWidget;
export '/pages/transfer_suscessful/transfer_suscessful_widget.dart'
    show TransferSuscessfulWidget;
export '/pages/accountandcard/accountandcard_widget.dart'
    show AccountandcardWidget;
export '/pages/delete_card/delete_card_widget.dart' show DeleteCardWidget;
export '/pages/withdraw_funds/withdraw_funds_widget.dart'
    show WithdrawFundsWidget;
export '/pages/mobileprepaid/mobileprepaid_widget.dart'
    show MobileprepaidWidget;
export '/pages/paythebill/paythebill_widget.dart' show PaythebillWidget;
export '/pages/makebillpayment/makebillpayment_widget.dart'
    show MakebillpaymentWidget;
export '/pages/saveonline/saveonline_widget.dart' show SaveonlineWidget;
export '/pages/addnewsavings/addnewsavings_widget.dart'
    show AddnewsavingsWidget;
export '/pages/transactionreport/transactionreport_widget.dart'
    show TransactionreportWidget;
export '/pages/beneficiary_page/beneficiary_page_widget.dart'
    show BeneficiaryPageWidget;
export '/pages/beneficiary_addnew/beneficiary_addnew_widget.dart'
    show BeneficiaryAddnewWidget;
export '/pages/settingspage/settingspage_widget.dart' show SettingspageWidget;
export '/pages/languagepage/languagepage_widget.dart' show LanguagepageWidget;
export '/pages/chnage_password/chnage_password_widget.dart'
    show ChnagePasswordWidget;
export '/pages/notification/notification_widget.dart' show NotificationWidget;
