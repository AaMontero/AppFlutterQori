package com.azabank.denoveo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
